﻿window.config =
{
    serverUrl: 'http://services.joehany.com/'
    //serverUrl: 'http://localhost:801'
}